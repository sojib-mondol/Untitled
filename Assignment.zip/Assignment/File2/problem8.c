/* Program that will take two numbers as inputs and
print the maximum value. (Using conditional operator - ?) */

#include<stdio.h>
int main()
{
    int x, y;
    scanf("%d %d", &x, &y);
    if(x != y)
    {
        if(x>y) printf("Max: %d\n", x);
        else printf("Max: %d\n", y);
    }

    return 0;
}
