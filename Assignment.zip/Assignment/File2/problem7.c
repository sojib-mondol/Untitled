/* Program that will declare and initialize
an integer and a floating point number.
Then it will perform floating to integer
and integer to floating conversions using
    (a) Assignment operation
    (b) Type casting */

#include<stdio.h>
int main()
{
    int a;
    float b;
    scanf("%d %f", &a, &b);
    printf("Assignment:   %f assigned to an int produces %d\n", b, (int)b);
    printf("Assignment:  %d assigned to a float produces %f\n", a, (float)a);
    printf("Type Casting: (float) %d produces %f\n", a, (float)a);
    printf("Type Casting: (int) %f produces -%d", b, (int)b);

    return 0;
}
