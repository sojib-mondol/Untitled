/*Program that will take a, b & c
as inputs and decide if the statements
are True (1) of False (0)
    a) (a+b)<=80
    b) !(a+c)
    c) a!=0
*/

#include<stdio.h>
int main()
{
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);

    if((a+b)<=80) printf("1\n");
    else printf("0\n");

    if(!(a+c)) printf("1\n");
    else printf("0\n");

    if(a!=0) printf("1\n");
    else printf("0\n");

    return 0;


}
