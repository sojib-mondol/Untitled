/*Program that will evaluate simple expressions of the form-

<number1>   <operator>   <number2>

; where operators are (+, - , *, /)

And if the operator is “/”, then check if <number2> nonzero or not. */

#include<stdio.h>
int main()
{
    int a;
    float b;
    char c;
    scanf("%d %c %f", &a, &c, &b);

    if(c == '*') printf("Multiplication:  %d\n", (int)(a*b));
    else if(c == '+') printf("Addison:  %d\n", (int)(a+b));
    else if(c == '-') printf("Subtraction:  %d\n", (int)(a-b));
    else if((b != 0) && (c == '/')) printf("Division:   %f\n", (float)(a/b));
    else printf("Division:    Zero as divisor is not valid!\n");

    return 0;
}
