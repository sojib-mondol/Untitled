/* Program that will categorize a single character that is entered
at the terminal, whether it is an alphabet, a digit or a special character. */

#include<stdio.h>
int main()
{
    char c;
    scanf("%c", &c);

    if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) printf("Alphabet\n");
    else if(c >= '0' && c <= '9') printf("Digit\n");
    else printf("Special\n");

    return 0;
}
