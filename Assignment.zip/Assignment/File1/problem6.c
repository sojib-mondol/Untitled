//Program that will take your age in year(s) as input and print it.
#include<stdio.h>
int main()
{
    int age;
    scanf("%d", &age);
    printf("My age is: %d\n", age);

    return 0;
}