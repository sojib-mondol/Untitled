/*Program that will declare a variable from each data type: double,
boolean. Then it will initialize them with values and print them. */

#include<stdio.h>
#include<stdbool.h>
int main()
{
    double d = 1.618039;
    bool b = true;

    printf("The double value: %lf\n", d);
    if(b == true) printf("The boolean value: 1\n");
    else printf("The boolean value: 0\n");

    return 0;

}
