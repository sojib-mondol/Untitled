/* Program that will declare a variable from each data type:
long int, long long int, long double, short int.
 Then it will initialize them with values and print them. */

#include<stdio.h>
int main()
{
    long int ln = 2147483647;
    long long int lln = 9223372036854775807;
    long double ld = 1.79769E+308;
    short int si = -32768;

    printf("The long int value: %li\n", ln);
    printf("The long long int value: %lli\n", lln);
    printf("The long double value: %Le\n", ld);
    printf("The short int value: %hd\n", si);

    return 0;
}
