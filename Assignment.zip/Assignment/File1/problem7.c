/*Program that will receive the values of an integer,
 a floating point number, a character from the keyboard
  and print those values. */

#include<stdio.h>
int main()
{
    int i;
    float f;
    char c;

    scanf("%d %f %c", &i, &f, &c);
    printf("The integer value: %d\nThe floating point value: %f\nThe character value: %c\n", i, f, c);

    return 0;
}